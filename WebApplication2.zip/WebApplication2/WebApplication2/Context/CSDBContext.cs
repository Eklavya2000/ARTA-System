﻿using CaseStudyApp.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Context
{
    public class CSDBContext:DbContext
    {
        public CSDBContext(DbContextOptions<CSDBContext> Context):base(Context)
        {

        }
        public DbSet<Customer> CustomerTbl { get; set; }
        public DbSet<Admin> AdminTbl { get; set; }
        //public DbSet<Product> ProductTbl { get; set; }
        public DbSet<Product> PTable { get; set; }
        public DbSet<InternalUser> UserTbl { get; set; }
        public DbSet<ProductEnquiry> EnquiryTbl { get; set; }
    }
}
