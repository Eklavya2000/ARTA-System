﻿using CaseStudyApp.Filters;
using CaseStudyApp.Model;
using CaseStudyApp.Model.ViewModel;
using CaseStudyApp.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Controllers
{   
    [ExceptionHandler]
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        readonly IAdminService _adminService;
        public AdminController(IAdminService adminService)
        {
            _adminService = adminService;
        }

        [Route("GetAdmin")]
        [HttpGet]
        public async Task<ActionResult> GetAdmin()
        {
            List<Admin> admin = await _adminService.GetAdmin();
            return Ok(admin);
        }
        [Route("AddAdmin")]
        [HttpPost]

        public async Task<ActionResult> AddAdmin(Admin admin)
        {
            string status = await _adminService.AddAdmin(admin);
            return Ok(status);
        }
        [Route("AdminLogin")]
        [HttpPost]
        public async Task<ActionResult> AdminLogin(AdminLogin adminLogin)
        {
            Admin admin = await _adminService.AdminLogin(adminLogin);
            return Ok("login successfull");
        }
        //Admin Managing Products
        [Route("AddProduct")]
        [HttpPost]
        public ActionResult AddProduct([FromForm] ImageUpload product)
        {
           //product.ProductImage =  _adminService.UploadImage(product.ProductImage);
            var status = _adminService.AddProduct(product);
            return Ok("Uploaded");
        }
        [Route("GetAllProducts")]
        [HttpGet]
        public ActionResult GetAllProducts()
        {
            List<Product> product = _adminService.GetAllProducts();
            return Ok(product);
        }
        [Route("GetProductById")]
        [HttpGet]
        public ActionResult GetProductById(int id)
        {
            Product getProduct = _adminService.GetProductById(id);
            if (getProduct == null)
            {
                return BadRequest($"Product with Id {id} not Found");
            }
            else
            {
                return Ok(getProduct);
            }
        }
        [Route("DeleteProduct")]
        [HttpDelete]
        public ActionResult DeleteProduct(int id)
        {
            string status = _adminService.DeleteProduct(id);
            return Ok(status);
        }
        
        //Admin Managing InternalUsers
        [Route("ManageUser")]
        [HttpPut]
        public ActionResult EditUser(int id,InternalUser user)
        {
            bool editStatus = _adminService.EditUser(id, user);
            return Ok(editStatus);
        }
        [Route("DeleteUser")]
        [HttpDelete]
        public ActionResult DeleteUser(int id)
        {
            string status = _adminService.DeleteUser(id);
            return Ok(status);
        }
        //Admin to active/deactivate users
        [Route("Activate/Deactivate")]
        [HttpPut]
        public ActionResult Activate_Deactivate(int id, string status)
        {
            bool editstatus = _adminService.userStatus(id, status);
            return Ok(editstatus);
        }

    }
}
