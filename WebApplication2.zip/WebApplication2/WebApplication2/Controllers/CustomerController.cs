﻿using CaseStudyApp.Filters;
using CaseStudyApp.Model;
using CaseStudyApp.Model.ViewModel;
using CaseStudyApp.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Controllers
{   
    [ExceptionHandler]
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class CustomerController : ControllerBase
    {
        readonly ICustomerService _customerService;
        readonly ITokenGenerator _tokenGenerator;

        public CustomerController(ICustomerService customerService,ITokenGenerator tokenGenerator)
        {
            _customerService = customerService;
            _tokenGenerator = tokenGenerator;
        }
        [Route("GetAllCustomers")]
        [HttpGet]
        public async Task<ActionResult> GetAllUsers()
        {
            List<Customer> customer = await _customerService.GetAllCustomers();
            return Ok(customer);
        }
        [Route("RegisterCustomer")]
        [HttpPost]
        public async Task<ActionResult> AddCustomer(Customer customer)
        {
            bool customerStatus = await _customerService.AddCustomer(customer);
            return Ok(customerStatus);
            //ModelState.Remove("UserId");
            //if (ModelState.IsValid)
            //{
            //    Customer customerStatus = await _customerService.AddCustomer(customer);
            //    return Ok("Registration Successfull");
            //}
            //else
            //{
            //    return Ok("Enter all details");
            //}
        }
        [Route("LoginCustomer")]
        [HttpPost]
        public async Task<ActionResult> CustomerLogin(CustomerLogin customerLogin)
        {
            Customer customer = await _customerService.CustomerLogin(customerLogin);
            //string userToken = _tokenGenerator.GenerateToken(customerLogin);
            return Ok("login successfull");
        }
        [Route("ForgotPassword")]
        [HttpGet]
        public async Task<IActionResult> ForgotPassword(string emailId)
        {
            var res = await _customerService.ForgotPassword(emailId);
            return Ok(res);
        }

        [Route("UpdateUser")]
        [HttpPut]
        //public async Task<IActionResult>EditUser(int id ,CustomerUpdate userUpdate)
        //{
        //    //userUpdate.DocImage = _customerService.UploadImage(userUpdate.DocImage);
        //    string editStatus =await _customerService.EditUser(id, userUpdate);
        //    return Ok(editStatus);
        //}
        public ActionResult EditUser(int id, Customer user)
        {
            bool editStatus = _customerService.EditUser(id, user);
            return Ok(editStatus);
        }
        [Route("UploadDocument")]
        [HttpPost]
        public ActionResult UploadImage([FromForm] Update userdetails)
        {
            userdetails.DocImage = _customerService.UploadImage(userdetails.DocImage);
            return Ok();
        }

        [Route("RaiseEnquiry")]
        [HttpPost]
        public ActionResult RaiseEnquiry([FromForm]Enquiry customerEnq)
        {
            var status = _customerService.RaiseEnquiry(customerEnq);
            return Ok("Uploaded");
        }

        [Route("GetAllMyRequests")]
        [HttpGet]
        public ActionResult GetAllRequests()
        {
            List<ProductEnquiry> req= _customerService.GetAllRequests();
            return Ok(req);
        }


    }
}

