﻿using CaseStudyApp.Filters;
using CaseStudyApp.Model;
using CaseStudyApp.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Controllers
{   
    
    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    public class InternalUserController : ControllerBase
    {
        readonly IInternalUserService _internalUserService;
        public InternalUserController(IInternalUserService internalUserService)
        {
            _internalUserService = internalUserService;
        }
        [Route("RegisterUser")]
        [HttpPost]
        public ActionResult RegisterInternalUser(InternalUser user)
        {
            string status = _internalUserService.AddUser(user);
            return Ok(status);
        }
        [Route("LoginUser")]
        [HttpPost]
        public ActionResult LoginInternalUser(InternalUserLogin userLogin)
        {   
            InternalUser user = _internalUserService.Login(userLogin);
            return Ok("Login Successfull");
        }
        [Route("GetAllRequests")]
        [HttpGet]
        public ActionResult GetAllRequests()
        {
            List<ProductEnquiry> req = _internalUserService.GetAllRequests();
            return Ok(req);
        }
        [Route("UpdateEnquiryStatus")]
        [HttpPut]
        public ActionResult UpdateStatus(int id,string status)
        {
            string editStatus = _internalUserService.EnquiryStatus(id, status);
            return Ok(editStatus);
        }
    }
}
