﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Exceptions
{
    public class AdminCredentialsInvalidException:ApplicationException
    {
        public AdminCredentialsInvalidException()
        {
                
        }
        public AdminCredentialsInvalidException(string message):base(message)
        {

        }
    }
}
