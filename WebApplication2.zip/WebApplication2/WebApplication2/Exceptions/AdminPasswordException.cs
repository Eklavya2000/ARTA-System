﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Exceptions
{
    public class AdminPasswordException:ApplicationException
    {
        public AdminPasswordException()
        {

        }
        public AdminPasswordException(string message):base(message)
        {

        }
    }
}
