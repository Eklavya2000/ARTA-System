﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Exceptions
{
    public class CustomerAlreadyExistsException:ApplicationException
    {
        public CustomerAlreadyExistsException()
        {

        }
        public CustomerAlreadyExistsException(string message):base(message)
        {

        }
    }
}
