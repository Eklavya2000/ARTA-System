﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Exceptions
{
    public class CustomerCredentialsInvalidException:ApplicationException
    {
        public CustomerCredentialsInvalidException()
        {

        }
        public CustomerCredentialsInvalidException(string message):base(message)
        {

        }
    }
}
