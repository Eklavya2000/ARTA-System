﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Exceptions
{
    public class CustomerPasswordException:ApplicationException
    {
        public CustomerPasswordException()
        {

        }
        public CustomerPasswordException(string message):base(message)
        {

        }
    }
}
