﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Exceptions
{
    public class CustomerUserIdException:ApplicationException
    {
        public CustomerUserIdException()
        {

        }
        public CustomerUserIdException(string message):base(message)
        {

        }
    }
}
