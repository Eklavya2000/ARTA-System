﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Exceptions
{
    public class InternalUserCredentialsInvalidException:ApplicationException
    {
        public InternalUserCredentialsInvalidException()
        {

        }
        public InternalUserCredentialsInvalidException(string message):base(message)
        {

        }
    }
}
