﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Exceptions
{
    public class InternalUserPasswordException : ApplicationException
    {
        public InternalUserPasswordException()
        {

        }
        public InternalUserPasswordException(string message):base(message)
        {

        }
    }
}
