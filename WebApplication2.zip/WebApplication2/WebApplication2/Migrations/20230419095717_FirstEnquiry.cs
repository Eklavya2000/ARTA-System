﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CaseStudyApp.Migrations
{
    public partial class FirstEnquiry : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "QueryStatus",
                table: "EnquiryTbl",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "QueryStatus",
                table: "EnquiryTbl");
        }
    }
}
