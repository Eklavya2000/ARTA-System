﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Model
{
    public class Customer
    {   [Key]
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string EmailAddress { get; set; }
        [DataType(DataType.PhoneNumber)]
        public int ContactNumber { get; set; }
        public string CompanyName { get; set; }
        public string UserType { get; set; }
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [DataType(DataType.Password)]
        //[Compare("Password",ErrorMessage ="Check Password")]
        public string ConfirmPassword { get; set; }

    }
}
