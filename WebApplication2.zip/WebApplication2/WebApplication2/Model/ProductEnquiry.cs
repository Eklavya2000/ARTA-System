﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Model
{
    public class ProductEnquiry
    {   [Key]
        public int? EnqId { get; set; }
        public string PImage { get; set; }
        public string Comments { get; set; }
        public string QueryStatus { get; set; } = "Open";
    }
}
