﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Model.ViewModel
{
    public class Enquiry
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int? EnqId { get; set; }
        public IFormFile PImage { get; set; }
        public string Comments { get; set; }
        public string QueryStatus { get; set; } = "Open";
    }
}
