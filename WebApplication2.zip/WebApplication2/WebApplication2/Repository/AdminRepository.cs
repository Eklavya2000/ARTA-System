﻿using CaseStudyApp.Context;
using CaseStudyApp.Exceptions;
using CaseStudyApp.Model;
using CaseStudyApp.Model.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Repository
{
    public class AdminRepository : IAdminRepository
    {
        readonly CSDBContext _csdbContext;
        readonly IWebHostEnvironment _webHostEnvironment;
        public AdminRepository(CSDBContext csdbContext, IWebHostEnvironment webHostEnvironment)
        {
            _csdbContext = csdbContext;
            _webHostEnvironment = webHostEnvironment;
        }

        public int AddAdmin(Admin admin)
        {
            _csdbContext.AdminTbl.Add(admin);
            return _csdbContext.SaveChanges();
        }

        

        public async Task<Admin> AdminLogin(AdminLogin adminLogin)
        {
            Admin loginAdmin = await _csdbContext.AdminTbl.Where(u => u.Email == adminLogin.Email).FirstOrDefaultAsync();
            if (loginAdmin != null)
            {
                if (loginAdmin.Password == adminLogin.Password)
                {
                    return loginAdmin;
                }
                else
                {
                    throw new AdminPasswordException($"Invalid Password");

                }
            }
            else
            {
                throw new AdminCredentialsInvalidException($"Invalid Credentials");
            }
        }

        public async Task<List<Admin>> GetAdmin()
        {
            return await _csdbContext.AdminTbl.ToListAsync();
        }

        public async Task<object> GetAdminById(int adminId)
        {
            return await _csdbContext.AdminTbl.Where(u => u.AdminId == adminId).FirstOrDefaultAsync();
        }

        public object AddProduct(ImageUpload product)
        {
            var path = _webHostEnvironment.WebRootPath;
            var filePath = "uploads/" + product.ProductImage.FileName;
            var fullPath = Path.Combine(path, filePath);
            UploadFile(product.ProductImage, fullPath);
            var data = new Product()
            {
                ProductName = product.ProductName,
                Description = product.Description,
                Quantity = product.Quantity,
                Rate = product.Rate,
                Specifiation = product.Specifiation,
                ProductImage = filePath
            };
            _csdbContext.PTable.Add(data);
            return _csdbContext.SaveChanges();
        }
        public void UploadFile(IFormFile file,string path)
        {
            FileStream stream = new FileStream(path, FileMode.Create);
            file.CopyTo(stream);
        }

        public List<Product> GetAllProducts()
        {
           return _csdbContext.PTable.ToList();
        }

        public Product GetProductById(int id)
        {
            return _csdbContext.PTable.Where(p => p.ProductId == id).FirstOrDefault();
        }

        public int DeleteProduct(Product productExists)
        {
            _csdbContext.PTable.Remove(productExists);
            return _csdbContext.SaveChanges();
        }

        public int EditUser(InternalUser user)
        {
            _csdbContext.Entry(user).State = EntityState.Modified;
            return _csdbContext.SaveChanges();
        }

        public InternalUser GetUserById(int id)
        {
            return _csdbContext.UserTbl.Where(u => u.Id == id).FirstOrDefault();
        }

        public int DeleteUser(InternalUser userExists)
        {
            _csdbContext.UserTbl.Remove(userExists);
            return _csdbContext.SaveChanges();
        }

        public InternalUser GetUser(int id, string status)
        {
            InternalUser user = _csdbContext.UserTbl.Where(u => u.Id == id).FirstOrDefault();
            user.Status = status;
            _csdbContext.SaveChanges();
            return user;
        }
        #region Product
        //    public object AddProduct(Product product)
        //    {

        //        _csdbContext.ProductTbl.Add(product);

        //        return _csdbContext.SaveChanges();
        //    }

        //    public IFormFile UploadImage(IFormFile productImage)
        //    {
        //        try
        //        {
        //            if (productImage.Length > 0)
        //            {
        //                string path = _webHostEnvironment.WebRootPath + "\\uploads\\";
        //                if (!Directory.Exists(path))
        //                {
        //                    Directory.CreateDirectory(path);
        //                }
        //                using (FileStream fileStream = System.IO.File.Create(path + productImage.FileName))
        //                {
        //                    productImage.CopyTo(fileStream);
        //                    fileStream.Flush();

        //                    return productImage;

        //                }

        //            }
        //            else
        //            {
        //                return null;
        //            }
        //        }
        //        catch (Exception )
        //        {
        //            return null;
        //        }
        //    }
        #endregion
    }

}
