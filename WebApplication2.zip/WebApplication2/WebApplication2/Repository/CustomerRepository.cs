﻿using CaseStudyApp.Context;
using CaseStudyApp.Exceptions;
using CaseStudyApp.Model;
using CaseStudyApp.Model.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Repository
{
    public class CustomerRepository : ICustomerRepository
    {
        readonly CSDBContext _csdbContext;
        readonly IWebHostEnvironment _webHostEnvironment;
        public CustomerRepository(CSDBContext csdbContext, IWebHostEnvironment webHostEnvironment)
        {
            _csdbContext = csdbContext;
            _webHostEnvironment = webHostEnvironment;
        }

        public int AddCustomer(Customer customer)
        {

            if (customer.Password == customer.ConfirmPassword)
            {
                _csdbContext.CustomerTbl.Add(customer);
                return _csdbContext.SaveChanges();
            }
            else
            {
                throw new CheckPasswordException($"ConfirmPassword doesnot match the Password");
            }
        }

        public async Task<Customer> CustomerLogin(CustomerLogin customerLogin)
        {
            //return await _csdbContext.CustomerTbl.Where(a => a.UserId == customerLogin.UserId && a.Password == customerLogin.Password).FirstOrDefaultAsync();
            Customer loginCustomer = await _csdbContext.CustomerTbl.Where(u => u.UserId == customerLogin.UserId && u.Password == customerLogin.Password).FirstOrDefaultAsync();
            if (loginCustomer != null)
            {
                if (loginCustomer.Password == customerLogin.Password)
                {
                    return loginCustomer;
                }
                else
                {
                    throw new CustomerPasswordException($"Invalid Password");

                }
            }
            else
            {
                throw new CustomerCredentialsInvalidException($"Invalid Credentials");
            }


        }



        public async Task<List<Customer>> GetAllCustomers()
        {
            return await _csdbContext.CustomerTbl.ToListAsync();
        }

        public async Task<object> GetCustomerByEmail(string emailId)
        {
            var ar = await _csdbContext.CustomerTbl.Where(u => u.EmailAddress == emailId).FirstOrDefaultAsync();
            if (ar == null)
            {
                return null;
            }
            else
            {
                return ar.Password;
            }
        }
        //public async Task<int> EditUser(CustomerUpdate userUpdate)
        //{
        //    _csdbContext.Entry(userUpdate).State = EntityState.Modified;
        //    return await _csdbContext.SaveChangesAsync();
        //}
        public int EditUser(Customer user)
        {
            _csdbContext.Entry(user).State = EntityState.Modified;
            return _csdbContext.SaveChanges();
        }

        public IFormFile UploadImage(IFormFile docImage)
        {
            try
            {
                if (docImage.Length > 0)
                {
                    string path = _webHostEnvironment.WebRootPath + "\\images\\";
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    using (FileStream fileStream = System.IO.File.Create(path + docImage.FileName))
                    {
                        docImage.CopyTo(fileStream);
                        fileStream.Flush();

                        return docImage;

                    }

                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public object RaiseEnquiry(Enquiry customerEnq)
        {
            var path = _webHostEnvironment.WebRootPath;
            var filePath = "adds/" + customerEnq.PImage.FileName;
            var fullPath = Path.Combine(path, filePath);
            UploadImgFile(customerEnq.PImage, fullPath);
            var data = new ProductEnquiry()
            {
                EnqId = customerEnq.EnqId,
                PImage = filePath,
                Comments = customerEnq.Comments

            };
            _csdbContext.EnquiryTbl.Add(data);
            return _csdbContext.SaveChanges();
        }
        public void UploadImgFile(IFormFile file, string path)
        {
            FileStream stream = new FileStream(path, FileMode.Create);
            file.CopyTo(stream);
        }

        public List<ProductEnquiry> GetAllRequests()
        {
            return _csdbContext.EnquiryTbl.ToList();
            
        }
    }
}

        //public async Task<string> ForgotPassword(string emailId)
        //{
        //    return await _csdbContext.CustomerTbl.Where(u => u.EmailAddress == emailId).FirstOrDefaultAsync();
        //}


        

