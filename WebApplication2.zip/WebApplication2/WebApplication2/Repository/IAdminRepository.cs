﻿using CaseStudyApp.Model;
using CaseStudyApp.Model.ViewModel;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Repository
{
    public interface IAdminRepository
    {
        Task<List<Admin>> GetAdmin();
        Task <object>GetAdminById(int adminId);
        int AddAdmin(Admin admin);
        Task<Admin> AdminLogin(AdminLogin adminLogin);
        object AddProduct(ImageUpload product);
        List<Product> GetAllProducts();
        Product GetProductById(int id);
        int DeleteProduct(Product productExists);
        int EditUser(InternalUser user);
        InternalUser GetUserById(int id);
        int DeleteUser(InternalUser userExists);
        InternalUser GetUser(int id, string status);
        //object AddProduct(Product product);
        //IFormFile UploadImage(IFormFile productImage);
    }
}
