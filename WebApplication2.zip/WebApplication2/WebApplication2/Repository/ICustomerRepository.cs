﻿using CaseStudyApp.Model;
using CaseStudyApp.Model.ViewModel;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Repository
{
    public interface ICustomerRepository
    {
        Task<List<Customer>> GetAllCustomers();
        int AddCustomer(Customer customer);
        Task <object> GetCustomerByEmail(string emailId);
        Task<Customer> CustomerLogin(CustomerLogin customerLogin);
        //Task<int> EditUser(CustomerUpdate userUpdate);
        IFormFile UploadImage(IFormFile docImage);
        int EditUser(Customer user);
        object RaiseEnquiry(Enquiry customerEnq);
        List<ProductEnquiry> GetAllRequests();
        //Task <string>ForgotPassword(string emailId);
    }
}
