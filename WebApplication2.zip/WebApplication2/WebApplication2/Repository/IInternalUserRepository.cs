﻿using CaseStudyApp.Controllers;
using CaseStudyApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Repository
{
    public interface IInternalUserRepository
    {
        string AddUser(InternalUser user);
        InternalUser Login(InternalUserLogin userLogin);
        List<ProductEnquiry> GetAllRequests();
        ProductEnquiry GetRequest(int id, string status);
    }
}
