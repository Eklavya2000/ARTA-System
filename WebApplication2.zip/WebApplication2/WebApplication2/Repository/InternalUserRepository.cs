﻿using CaseStudyApp.Context;
using CaseStudyApp.Controllers;
using CaseStudyApp.Exceptions;
using CaseStudyApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Repository
{   
    public class InternalUserRepository : IInternalUserRepository
    {
        readonly CSDBContext _csdbContext;
        public InternalUserRepository(CSDBContext csdbContext)
        {
            _csdbContext = csdbContext;
        }

        public string AddUser(InternalUser user)
        {
            _csdbContext.UserTbl.Add(user);
            return _csdbContext.SaveChanges().ToString();
        }

        
        public InternalUser Login(InternalUserLogin userLogin)
        {
            InternalUser user =  _csdbContext.UserTbl.Where(u => u.UserName == userLogin.UserName).FirstOrDefault();
            if (user != null)
            {
                if (user.Password == userLogin.Password)
                {
                    return user;
                }
                else
                {
                    throw new InternalUserPasswordException($"Invalid LoginPassword");

                }
            }
            else
            {
                throw new InternalUserCredentialsInvalidException($"Invalid Credentials");
            }
        }
        public List<ProductEnquiry> GetAllRequests()
        {
            return _csdbContext.EnquiryTbl.ToList();
        }

        public ProductEnquiry GetRequest(int id, string status)
        {
            ProductEnquiry request = _csdbContext.EnquiryTbl.Where(u => u.EnqId == id).FirstOrDefault();
            request.QueryStatus = status;
            _csdbContext.SaveChanges();
            return request;
        }
    }
}
