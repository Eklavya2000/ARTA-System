﻿using CaseStudyApp.Model;
using CaseStudyApp.Model.ViewModel;
using CaseStudyApp.Repository;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Service
{
    public class AdminService : IAdminService
    {
        readonly IAdminRepository _adminRepository;
        //readonly IWebHostEnvironment _webHostEnvironment;
        public AdminService(IAdminRepository adminRepository)
        {
            _adminRepository = adminRepository;
            //_webHostEnvironment = webHostEnvironment;
        }

        public async Task<string> AddAdmin(Admin admin)
        {
            var adminExists = await _adminRepository.GetAdminById(admin.AdminId);
            if (adminExists == null)
            {
                int status = _adminRepository.AddAdmin(admin);
                if (status == 1)
                {
                    return $"Admin Added Successfully";
                }
                else
                {
                    return $"Not Registred";
                }
            }
            else
            {
                return "Not Registered";
            }
        }


        //public object AddProduct(Product product)
        //{
        //    return _adminRepository.AddProduct(product);
        //}

        public async Task<Admin> AdminLogin(AdminLogin adminLogin)
        {
            return await _adminRepository.AdminLogin(adminLogin);
        }

        public async Task<List<Admin>> GetAdmin()
        {
            return await _adminRepository.GetAdmin();
        }
        //Managing Products
        public object AddProduct(ImageUpload product)
        {
            return _adminRepository.AddProduct(product);
        }
        public List<Product> GetAllProducts()
        {
            return _adminRepository.GetAllProducts();
        }

        public Product GetProductById(int id)
        {
            return _adminRepository.GetProductById(id);
        }
        public string DeleteProduct(int id)
        {
            Product productExists = _adminRepository.GetProductById(id);
            if (productExists != null)
            {
                int status = _adminRepository.DeleteProduct(productExists);
                if (status == 1)
                {
                    return "Deleted Successfully";
                }
                else
                {
                    return "failed to delete ";
                }
            }
            else
            {
                return "Product not found";
            }
        }
        //Managing InternalUser 
        public bool EditUser(int id, InternalUser user)
        {
            user.Id = id;
            int editStatus = _adminRepository.EditUser(user);
            if (editStatus == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string DeleteUser(int id)
        {
            InternalUser userExists = _adminRepository.GetUserById(id);
            if (userExists != null)
            {
                int status = _adminRepository.DeleteUser(userExists);
                if (status == 1)
                {
                    return "Deleted Successfully";
                }
                else
                {
                    return "failed to delete ";
                }
            }
            else
            {
                return "User not found";
            }
        }

        public bool userStatus(int id, string status)
        {
                InternalUser user = _adminRepository.GetUser(id, status);
                return user != null ? true : false;
            
        }



        #region uploadImage
        //public IFormFile UploadImage(IFormFile productImage)
        //{
        //   return _adminRepository.UploadImage(productImage);

        //    //    try
        //    //    {
        //    //        if (productImage.Length > 0)
        //    //        {
        //    //            string path =  _webHostEnvironment.WebRootPath + "\\uploads\\";
        //    //            if (!Directory.Exists(path))
        //    //            {
        //    //                Directory.CreateDirectory(path);
        //    //            }
        //    //            using(FileStream fileStream = System.IO.File.Create(path + productImage.FileName))
        //    //            {
        //    //                productImage.CopyTo(fileStream);
        //    //                fileStream.Flush();
        //    //                return ;
        //    //            }

        //    //        }
        //    //        else
        //    //        {
        //    //            return null;
        //    //        }
        //    //    }
        //    //    catch(Exception)
        //    //    {
        //    //        return null;
        //    //    }
        //    //}
        //}
        #endregion


    }
}
