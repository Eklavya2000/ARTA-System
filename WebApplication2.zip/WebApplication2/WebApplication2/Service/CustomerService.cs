﻿using CaseStudyApp.Exceptions;
using CaseStudyApp.Model;
using CaseStudyApp.Model.ViewModel;
using CaseStudyApp.Repository;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Service
{
    public class CustomerService : ICustomerService
    {
        readonly ICustomerRepository _customerRepository;
        public CustomerService(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }

        public async Task<List<Customer>> GetAllCustomers()
        {
            return await _customerRepository.GetAllCustomers();
        }
        public async Task<bool> AddCustomer(Customer customer)
        {
            var customerExists = await _customerRepository.GetCustomerByEmail(customer.EmailAddress);
            if (customerExists == null)
            {
                int status= _customerRepository.AddCustomer(customer);
                if (status == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                throw new CustomerAlreadyExistsException($"EmailId :{customer.EmailAddress}  \nThis Customer Already Exist with this EmailId ");
            }
        }
        public async Task<Customer> CustomerLogin(CustomerLogin customerLogin)
        {
            Customer customer = await _customerRepository.CustomerLogin(customerLogin);
            if (customer != null)
            {
                return customer;
            }
            else throw new CustomerCredentialsInvalidException($"UserId/Password are invalid \n If you are new user try to Register");
        }

        public async Task<object> ForgotPassword(string emailId)
        {
            var forgotPassword = await _customerRepository.GetCustomerByEmail(emailId);
            return forgotPassword.ToString();
        }

        //public async Task<string> EditUser(int id, CustomerUpdate userUpdate)
        //{
        //    userUpdate.UserId = id;
        //    int editStatus = await _customerRepository.EditUser(userUpdate);
        //    if (editStatus == 1)
        //    {
        //        return "Success";
        //    }
        //    else
        //    {
        //        return "failed";
        //    }
        //}

        public IFormFile UploadImage(IFormFile docImage)
        {
            return _customerRepository.UploadImage(docImage);
        }

        public bool EditUser(int id, Customer user)
        {
            user.UserId = id;
            int editStatus = _customerRepository.EditUser(user);
            if (editStatus == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public object RaiseEnquiry(Enquiry customerEnq)
        {
            return _customerRepository.RaiseEnquiry(customerEnq);
        }

        public List<ProductEnquiry> GetAllRequests()
        {
            return _customerRepository.GetAllRequests();
        }
    }
}
