﻿using CaseStudyApp.Model;
using CaseStudyApp.Model.ViewModel;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Service
{
    public interface IAdminService
    {
        Task<List<Admin>> GetAdmin();
        Task<string> AddAdmin(Admin admin);
        Task<Admin> AdminLogin(AdminLogin adminLogin);
        object AddProduct(ImageUpload product);
        List<Product> GetAllProducts();
        Product GetProductById(int id);
        string DeleteProduct(int id);
        bool EditUser(int id, InternalUser user);
        string DeleteUser(int id);
        bool userStatus(int id, string status);
        //IFormFile UploadImage(IFormFile productImage);
        //object AddProduct(Product product);

    }
}
