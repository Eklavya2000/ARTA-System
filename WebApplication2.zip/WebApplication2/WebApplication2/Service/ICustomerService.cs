﻿using CaseStudyApp.Model;
using CaseStudyApp.Model.ViewModel;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Service
{
    public interface ICustomerService
    {
        Task<List<Customer>> GetAllCustomers();
        Task<bool> AddCustomer(Customer customer);
        Task<Customer> CustomerLogin(CustomerLogin customerLogin);
        Task <object> ForgotPassword(string emailId);
        //Task<string> EditUser(int id, CustomerUpdate userUpdate);
        IFormFile UploadImage(IFormFile docImage);
        bool EditUser(int id, Customer user);
        object RaiseEnquiry(Enquiry customerEnq);
        List<ProductEnquiry> GetAllRequests();
        //Task<string> EditUser(int? userId, Update userUpdate);
    }
}
