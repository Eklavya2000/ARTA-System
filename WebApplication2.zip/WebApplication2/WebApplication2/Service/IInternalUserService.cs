﻿using CaseStudyApp.Controllers;
using CaseStudyApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Service
{
    public interface IInternalUserService
    {
        string AddUser(InternalUser user);
        InternalUser Login(InternalUserLogin userLogin);
    }
}
