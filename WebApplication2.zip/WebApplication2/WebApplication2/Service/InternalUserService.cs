﻿using CaseStudyApp.Controllers;
using CaseStudyApp.Model;
using CaseStudyApp.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Service
{
    public class InternalUserService : IInternalUserService
    {
        readonly IInternalUserRepository _internalUserRepository;
        public InternalUserService(IInternalUserRepository internalUserRepository)
        {
            _internalUserRepository = internalUserRepository;
        }

        public string AddUser(InternalUser user)
        {
            return _internalUserRepository.AddUser(user);
        }


        public InternalUser Login(InternalUserLogin userLogin)
        {
            return _internalUserRepository.Login(userLogin);
        }
        public List<ProductEnquiry> GetAllRequests()
        {
            return _internalUserRepository.GetAllRequests();
        }

        public string EnquiryStatus(int id, string status)
        {
            ProductEnquiry request = _internalUserRepository.GetRequest(id, status);
            return request != null ? "Updated" : "Not Updated";
        }
    }
}
