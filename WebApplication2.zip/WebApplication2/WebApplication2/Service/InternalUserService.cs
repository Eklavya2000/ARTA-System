﻿using CaseStudyApp.Controllers;
using CaseStudyApp.Model;
using CaseStudyApp.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudyApp.Service
{
    public class InternalUserService : IInternalUserService
    {
        readonly IInternalUserRepository _internalUserRepository;
        public InternalUserService(IInternalUserRepository internalUserRepository)
        {
            _internalUserRepository = internalUserRepository;
        }

        public string AddUser(InternalUser user)
        {
            return _internalUserRepository.AddUser(user);
        }

        public InternalUser Login(InternalUserLogin userLogin)
        {
            return _internalUserRepository.Login(userLogin);
        }
    }
}
