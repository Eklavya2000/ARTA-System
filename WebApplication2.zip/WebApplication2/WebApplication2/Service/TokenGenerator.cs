﻿using CaseStudyApp.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace CaseStudyApp.Service
{
    public class TokenGenerator : ITokenGenerator
    {
        readonly IConfiguration _configuration;
        //constructor
        public TokenGenerator(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public string GenerateToken(CustomerLogin customerLogin)
        {
            #region
            //    var userClaims = new Claim[]
            //    {
            //        new Claim(JwtRegisteredClaimNames.Jti,new Guid().ToString()),
            //        new Claim(JwtRegisteredClaimNames.UniqueName,userName)
            //    };
            //    var userSecurityKey = Encoding.UTF8.GetBytes("thisisthekeyforvalidation");
            //    var userSymmetricSecurityKey = new SymmetricSecurityKey(userSecurityKey);
            //    var userSigninCredentials = new SigningCredentials(userSymmetricSecurityKey, SecurityAlgorithms.HmacSha256);
            //    var userJwtSecurityToken = new JwtSecurityToken
            //        (
            //        issuer: "WEBAPI",
            //        audience: "WEBAPIUser",
            //        claims: userClaims,
            //        expires: DateTime.UtcNow.AddMinutes(10),
            //        signingCredentials: userSigninCredentials
            //        );
            //    var userSecurityTokenHandler = new JwtSecurityTokenHandler().WriteToken(userJwtSecurityToken);
            //    return userSecurityTokenHandler;
            //}
            #endregion
            var key = _configuration.GetValue<string>("JwtConfig:Key");
            var keyBytes = Encoding.UTF8.GetBytes(key);
            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenDescriptor = new SecurityTokenDescriptor()
            {
                Subject = new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.NameIdentifier, customerLogin.Password)
            }),
                Expires = DateTime.UtcNow.AddMinutes(60),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(keyBytes), SecurityAlgorithms.HmacSha256Signature)



            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);


        }
    }
}
