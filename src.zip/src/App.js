import './App.css';
import Login from './Component/Login';
import Signup from  './Component/Signup';
import { BrowserRouter, Routes, Route} from 'react-router-dom'
import HomePage from './Component/HomePage';
import ContactUs from './Component/ContactUs';

import Mycard1 from './Component/ProductDetails/Mycard1';
import Mycard2 from './Component/ProductDetails/Mycard2';
import Mycard3 from './Component/ProductDetails/Mycard3';





function App() {
  return (
    <>
    

    
    <BrowserRouter>
    <Routes>
      
    <Route path='/' element={<Login/>}></Route>
    <Route path='/Signup' element={<Signup/>}></Route> 
    <Route path='/HomePage' element={<HomePage/>}></Route> 
    <Route path='/ContactUs' element={<ContactUs/>}></Route> 
    </Routes>
    </BrowserRouter>
  

    </>
  );
  
}

export default App;
