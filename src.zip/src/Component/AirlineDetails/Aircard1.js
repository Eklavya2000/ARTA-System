import React from "react";
import "./Aircard1.css"
import { Link } from "react-router-dom";


const Aircard1 =  (props) =>{
    return(
<>
        <div className="Aircard1">Client No {props.cardno} <br></br><br></br><h4 id="head1"> <marquee> Holiday Inn</marquee></h4>


                        
                    
        </div>


    </>
    )

}
export default Aircard1;