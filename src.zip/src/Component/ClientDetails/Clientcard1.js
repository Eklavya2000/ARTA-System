import React from "react";
import "./Clientcard1.css"
import { Link } from "react-router-dom";


const Clientcard1 =  (props) =>{
    return(
<>
        <div className="Clientcard1">Client No {props.cardno} <br></br><br></br><h4 id="head1"> <marquee> Holiday Inn</marquee></h4>


                        
                    
        </div>


    </>
    )

}
export default Clientcard1;