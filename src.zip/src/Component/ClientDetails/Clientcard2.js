import React from "react";
import "./Clientcard2.css"
import { Link } from "react-router-dom";


const Clientcard2 =  (props) =>{
    return(
<>
        <div className="Clientcard2">Client  No {props.cardno} <br></br><br></br><h4 id="head2"> <marquee> Holiday Inn</marquee></h4>


                        
                    
        </div>


    </>
    )

}
export default Clientcard2;