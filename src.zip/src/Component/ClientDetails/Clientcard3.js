import React from "react";
import "./Clientcard3.css"
import { Link } from "react-router-dom";


const Clientcard3 =  (props) =>{
    return(
<>
        <div className="Clientcard3">Client No {props.cardno} <br></br><br></br><h4 id="head3"> <marquee> Holiday Inn</marquee></h4>


                        
                    
        </div>


    </>
    )

}
export default Clientcard3;