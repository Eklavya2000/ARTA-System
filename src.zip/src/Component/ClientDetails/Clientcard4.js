import React from "react";
import "./Clientcard4.css"
import { Link } from "react-router-dom";


const Clientcard4 =  (props) =>{
    return(
<>
        <div className="Clientcard4">Client No {props.cardno} <br></br><br></br><h4 id="head4"> <marquee> Holiday Inn</marquee></h4>


                        
                    
        </div>


    </>
    )

}
export default Clientcard4;