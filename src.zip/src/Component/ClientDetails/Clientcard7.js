import React from "react";
import "./Clientcard7.css"
import { Link } from "react-router-dom";


const Clientcard7 =  (props) =>{
    return(
<>
        <div className="Clientcard7">Client No {props.cardno} <br></br><br></br><h4 id="head7"> <marquee> Holiday Inn</marquee></h4>


                        
                    
        </div>


    </>
    )

}
export default Clientcard7;