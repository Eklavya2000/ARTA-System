import React from "react";
import "./Clientcard8.css"
import { Link } from "react-router-dom";


const Clientcard8 =  (props) =>{
    return(
<>
        <div className="Clientcard8">Client No {props.cardno} <br></br><br></br><h4 id="head7"> <marquee> Holiday Inn</marquee></h4>


                        
                    
        </div>


    </>
    )

}
export default Clientcard8;