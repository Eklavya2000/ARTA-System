import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import "./ContactUs.css";


function ContactUs (){
    return(

        //  [values, setValues]=useState({
        //     Name: '',
        //     PhoneNumber: ''
        // })
    
    
        // const [errors, setErrors] = useState({})
        // const handleInput= (event) => {
        //     setValues(prev  => ({...prev, [event.target.name]: [event.target.value]}))
        // }
    
        // const handleSubmit= (event) =>{
        //     event.preventDefault();
        //     setErrors(Validation(values));
        // }

<div className='ContactUs-Bg'>
        <div  style={{
            textAlign : "center" , paddingTop : "150px"
        }}>
         <div className='d-flex justify-content-center align-items-center'> 
        
            <div className='bg-white p-3 rounded w-25'>
                <h2>ContactUs</h2>
                <form action="" >


                <div className='mb-3'>
                        <label hconsttmlFor='Name'>Name</label><br></br>
                        <input type="Name" placeholder='Enter Name' name='Name'
                        
                        className='Form-control rounded-0'/>

                        {/* {errors.Name && <span className='text-danger'>{errors.Name}</span>} */}
                    </div>


                    <div className='mb-3'>

                        <label htmlFor='PhoneNumber'>PhoneNumber</label><br></br>
                        <input type="PhoneNumber" placeholder='Enter PhoneNumber' name='PhoneNumber'
                        
                        className='Form-control rounded-0'/>
                        {/* {errors.PhoneNumber && <span className='text-danger'>{errors.PhoneNumber}</span>} */}
                    </div>

                    <button type='submit' className='btn btn-success w-100 rounded-0'> <strong>Submit</strong></button>
                    <p>We Will Respond You Soon...</p>
                     
                    <button type='submit' className='btn btn-success w-100 rounded-0'> <strong>Need More Help ?</strong></button>
                    {/* <Link to="/Signup" className='btn btn-default border w-100 bg-light rounded-0'><strong>Signup</strong></Link>
                    <Link to="/HomePage" className='btn btn-default border w-100 bg-light rounded-0'><strong>Back To HomePage</strong></Link> */}
                </form>
             </div>

        </div>
        </div>
        
        </div>


    

    )
                }

export default ContactUs;