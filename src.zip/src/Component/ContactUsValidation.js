// function CValidation(values){
//     let error = {}
    
//      const Name_pattern = /^[a-zA-Z\-\1-9]+$/
//      const PhoneNumber_pattern = /^[a-zA-Z\-\1-9]+$/
    
//         if(values.Name === ""){
//             error.Name = "Name Should Not Be Empty"
//         }
//         else if(!UsernName_pattern.test(values.Name)){
//             error.Name = "Name Didn't Match"
//         } else {
//             error.Name=""
//         }
    
    
//         if(values.PhoneNumber ===""){
//             error.PhoneNumber= "PhoneNumber Should Not Be Empty"
//         }
//         else if(!PhoneNumber_pattern.test(values.PhoneNumber)){
//             error.PhoneNumber = "PhoneNumber Didn't Match"
//         } else {
//             error.PhoneNumber=""
//         }
//         return error;
//     }
    
//     export default CValidation;