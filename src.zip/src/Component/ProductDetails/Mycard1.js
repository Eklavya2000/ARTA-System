import React from "react";
import "./Mycard1.css"
import { Link } from "react-router-dom";


const Mycard1 =  (props) =>{
    return(
<>
        <div className="Mycard-1">Product No {props.cardno} <br></br><br></br><h4 id="head1"> <marquee> Holiday Inn</marquee></h4>

        <br></br>
        <br></br>
        
        <button type='submit' id="Mycard1-btn" className='Mycard1-btn'> <strong>View</strong></button>   

                        
                    
        </div>


    </>
    )

}
export default Mycard1;