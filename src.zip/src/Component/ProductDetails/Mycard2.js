import React from "react";
import "./Mycard2.css"


const Mycard2 =  (props) =>{
    return(
        
        <div className="Mycard-2">Product No {props.cardno} <br></br><br></br><h4 id="head2"> <marquee>Royal Kingdom Resort</marquee></h4>
        
        
        
        <br></br>
        <br></br>
        
        <button type='submit' id="Mycard2-btn" className='Mycard2-btn'> <strong>View</strong></button>   
        
        
        
        </div>


    


    )

}
export default Mycard2;