import React from "react";
import "./Mycard3.css"


const Mycard3 =  (props) =>{
    return(
<>
        <div className="Mycard-3">Product No {props.cardno} <br></br><br></br><h4 id="head3"> <marquee>Tata Hospital</marquee></h4>
        
        
        <br></br>
        <br></br>
        
        <button type='submit' id="Mycard3-btn" className='Mycard3-btn'> <strong>View</strong></button>   
        
        
        
        </div>

    </>

    )
}
export default Mycard3;