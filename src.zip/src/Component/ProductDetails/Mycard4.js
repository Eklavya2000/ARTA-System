import React from "react";
import "./Mycard4.css"


const Mycard4 =  (props) =>{
    return(
<>
        <div className="Mycard-4">Product No {props.cardno} <br></br><br></br><h4 id="head4"> <marquee>Cafe Coffee Day</marquee></h4>


        <br></br>
        <br></br>
        
        <button type='submit' id="Mycard4-btn" className='Mycard4-btn'> <strong>View</strong></button>

</div>
    </>

    )
}
export default Mycard4;