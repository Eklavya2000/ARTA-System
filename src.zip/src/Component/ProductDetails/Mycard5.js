import React from "react";
import "./Mycard5.css"


const Mycard5 =  (props) =>{
    return(

        <div className="Mycard-5">Product No {props.cardno} <br></br><br></br><h4 id="head5"> <marquee>Ola Taxi</marquee></h4>
        
        
        <br></br>
        <br></br>
        
        <button type='submit' id="Mycard5-btn" className='Mycard5-btn'> <strong>View</strong></button>
        
        
        
        
        </div>

    

    )
}
export default Mycard5;