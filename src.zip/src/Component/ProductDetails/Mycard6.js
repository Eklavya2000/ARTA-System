import React from "react";
import "./Mycard6.css"


const Mycard6 =  (props) =>{
    return(

        <div className="Mycard-6">Product No {props.cardno}<br></br><br></br><h4 id="head6"> <marquee>Thunder Bus Service</marquee></h4>
        
        
        <br></br>
        <br></br>
        
        <button type='submit' id="Mycard6-btn" className='Mycard6-btn'> <strong>View</strong></button>
        
        
        </div>


    )




}
export default Mycard6;