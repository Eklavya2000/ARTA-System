import React from "react";
import "./Mycard7.css"


const Mycard7 =  (props) =>{
    return(

        <div className="Mycard-7">Product No {props.cardno} <br></br><br></br><h4 id="head7"> <marquee>Fitness Fuel</marquee></h4>
        
        
        <br></br>
        <br></br>
        
        <button type='submit' id="Mycard7-btn" className='Mycard7-btn'> <strong>View</strong></button>
        
        
        
        
        </div>
    

  

    )
}
export default Mycard7;