import React from "react";
import "./Mycard8.css"


const Mycard8 =  (props) =>{
    return(
<>
        <div className="Mycard-8">Product No {props.cardno} <br></br><br></br><h4 id="head8"> <marquee>Air India</marquee></h4>
        
        <br></br>
        <br></br>
        
        <button type='submit' id="Mycard8-btn" className='Mycard8-btn'> <strong>View</strong></button>
        
        
        
        
        </div>

    </>

    )
}
export default Mycard8;