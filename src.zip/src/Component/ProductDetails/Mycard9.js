import React from "react";
import "./Mycard9.css"


const Mycard9 =  (props) =>{
    return(
<>
        <div className="Mycard-9">Product No {props.cardno} <br></br><br></br><h4 id="head9"> <marquee>Amazon Inc</marquee></h4>
        
        <br></br>
        <br></br>
        
        <button type='submit' id="Mycard9-btn" className='Mycard9-btn'> <strong>View</strong></button>
        
        
        
        </div>
        


    </>

    )
}
export default Mycard9;